//NAME: Eugene Choi
//EMAIL: echoi2@g.ucla.edu
//UID: 905368197

#include <stdio.h>
#include <stdlib.h> 
#include <errno.h>
#include <getopt.h>
#include <unistd.h>
#include <termios.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <signal.h>
#include <string.h>
#include <poll.h>       
#include <sys/socket.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <netinet/in.h>
#include <netdb.h>
#include <fcntl.h>
#include "zlib.h"

z_stream comp_to_serv;
z_stream decomp_from_serv;

struct termios save_beginning; //Struct that saves the current terminal mode

void set_to_nc_input(); //setting mode to non-cannonical input mode

void reset_input_mode(); //resets back to cannonical input mode (restores original state)

void read_input_kb_to_socket(struct pollfd fds[], int log_opt,int log_fd, int comp_opt);

void init_compress_to_stream(); //deflate

void init_decomp_from_stream(); //inflate

void compEnd(); //end compression and set terminal mode back to normal

void deflate_stream(void * orig_buf, int orig_len, void * out_buf, int out_len);

void inflate_stream(void * orig_buf, int orig_len, void * out_buf, int out_len);

int client_connect(char* hostname, unsigned int port_num);

int read_input_sock_to_disp(struct pollfd fds[], int log_opt, int log_fd, int comp_opt);


int main(int argc, char* argv[]){
	int option_index = 0;
	int opt = 0;
	int socket_fd, port, port_opt, log_opt, log_fd, comp_opt;
	char* filename; //for log option
	char* hostname;


	port_opt = 0;
	log_opt = 0;
	comp_opt = 0;
	port = -1;
	hostname = "localhost";
	filename = NULL;

	static struct option long_options[] = {
	{"port", required_argument, NULL, 'p'},
	{"log", required_argument, NULL, 'l'},
	{"compress", no_argument, NULL, 'c'},
	{0,0,0,0}};

	while((opt = getopt_long(argc, argv, "p:l:cd", long_options, &option_index)) != -1){
		switch(opt){
			case 'p':
				port_opt = 1;
				port = atoi(optarg); //Grabs the argument (port # in string) for the port option and converts it into an int.
				break;
			case 'l':
				log_opt = 1;
				filename = optarg;
				break;
			case 'c':
				comp_opt = 1;
				break;
			default:
				fprintf(stderr,"Error: The option/options provided are incorrect. The only options with arguments accepted are --port=port#, --log=filename, --compress, and --debug.");	
				exit(1);
		}
	} //closes while opt loop
	
	if(port_opt == 0){
		fprintf(stderr,"Error: Port option is mandatory");
		exit(1);
	}
	if(comp_opt == 1){
		init_compress_to_stream(); //deflate
		init_decomp_from_stream(); //inflation
		atexit(compEnd);
	}

	set_to_nc_input(); //setting terminal to non-canonical input mode
	if(comp_opt == 0){
		atexit(reset_input_mode);
	}




	if(port_opt == 1){
		if(port == -1){
			fprintf(stderr,"Error: Port number is bad.");
			exit(1);
		}

		if(log_opt == 1){
			if(filename == NULL){
				fprintf(stderr,"Error: Invalid filename.");
				exit(1);
			}
			if((log_fd = creat(filename, 0777)) == -1){
				fprintf(stderr,"Error: Could not create log.\nMessage: %s\nExiting with error number: %d\n", strerror(errno), errno);
				exit(1);
			}
		}

		socket_fd = client_connect(hostname, port);

		struct pollfd fds[2];
		int poll_value;
		fds[0].fd = 0; //stdin
		fds[1].fd = socket_fd;	//socket
		fds[0].events = POLLIN | POLLHUP | POLLERR;
		fds[1].events = POLLIN | POLLHUP | POLLERR;

		while(1){
			poll_value = poll(fds, 2, 0);
			if(poll_value > 0){



				if(fds[0].revents & POLLIN){ //means that there's input to read in from stdin (fds[0])
					read_input_kb_to_socket(fds, log_opt, log_fd, comp_opt);
				}
				if(fds[0].revents & POLLHUP){
					exit(0);
				}
				if(fds[0].revents & POLLERR){
					fprintf(stderr,"Error: Received a POLLERR.\nMessage: %s\nExiting with error number: %d\n", strerror(errno), errno);
					exit(1);
				}





				if(fds[1].revents & POLLIN){  //means that there's input from the socket to be displayed via stdout
					int read_write_fin;
					if((read_write_fin = read_input_sock_to_disp(fds, log_opt, log_fd, comp_opt)) == 0){
						exit(0);
					}
				}
				if(fds[1].revents & POLLHUP){
					exit(0);
				}
				if(fds[1].revents & POLLERR){
					fprintf(stderr,"Error: Received a POLLERR.\nMessage: %s\nExiting with error number: %d\n", strerror(errno), errno);
					exit(1);
				}



			} //closes if poll_val > 0

			else if(poll_value < 0){
				fprintf(stderr, "Error: poll failed.\nMessage: %s\nExiting with error number: %d\n", strerror(errno), errno);
				exit(1);
			} //closes else if poll_val < 0
		} //closes the while 1 loop

	} //closes else loop for the big else
	exit(0);
} //closes int main



void set_to_nc_input(){ 
  int grabbedAttributes = tcgetattr(0, &save_beginning);
  if(grabbedAttributes < 0){
    fprintf(stderr, "Error: Could not grab attributes.\nMessage: %s\nExiting with error number: %d\n", strerror(errno), errno);
    exit(1);
  }
  struct termios copy_att;
  tcgetattr(0, &copy_att); //grabs and copies attributes from file descriptor into copy_att
  copy_att.c_iflag = ISTRIP;
  copy_att.c_oflag = 0;
  copy_att.c_lflag = 0;
  int setting_changes = tcsetattr(0, TCSANOW, &copy_att);
  if(setting_changes < 0){
    fprintf(stderr, "Error: Could not change attributes.\nMessage: %s\nExiting with error number: %d\n", strerror(errno), errno);
    exit(1);
  }
}



void reset_input_mode(){
  if(tcsetattr(STDIN_FILENO, TCSANOW, &save_beginning) < 0){
    fprintf(stderr, "Error: Could not restore original terminal attributes.\nMessage: %s\nExiting with error number: %d\n", strerror(errno), errno);
    exit(1);
  }
}


void read_input_kb_to_socket(struct pollfd fds[], int log_opt, int log_fd, int comp_opt){
	char char_buf[2048];
	char curr_char;
	int readable;
	if((readable = read(0, &char_buf, 2048)) == -1){
		fprintf(stderr, "Error: Could not read.\nMessage: %s\nExiting with error number: %d\n", strerror(errno), errno);
		exit(1);
	}

	int k = 0;
	while(k < readable){
	curr_char = char_buf[k];
		switch(curr_char){
			//case '0x03':  
			//case '0x04': these two not needed cause ^C and ^D are just passed to server like normal characters and handled there	
			case '\r':
			case '\n':
				if(write(1, "\r", 1) < 0){
					fprintf(stderr, "Error: Could not write.\nMessage: %s\nExiting with error number: %d\n", strerror(errno), errno);
					exit(1);
				}
				if(write(1, "\n", 1) < 0){
					fprintf(stderr, "Error: Could not write.\nMessage: %s\nExiting with error number: %d\n", strerror(errno), errno);
					exit(1);
				}
				break;
			default:
				if(write(1, &curr_char, 1) < 0){
					fprintf(stderr, "Error: Could not write.\nMessage: %s\nExiting with error number: %d\n", strerror(errno), errno);
					exit(1);
				}
				break;
		} //closes switch statement
		k++;
	} //closes while i < readable 





	if(comp_opt == 1){ //compressed
		char comp_buf[2048];
		deflate_stream(char_buf, readable, comp_buf, 2048);
		if(write(fds[1].fd, &comp_buf, 2048 - comp_to_serv.avail_out) < 0){
			fprintf(stderr, "Error: Could not write.\nMessage: %s\nExiting with error number: %d\n", strerror(errno), errno);
			exit(1);
		}
		//write(1, &comp_buf, 2048 - comp_to_serv.avail_out); //TEST

		if(log_opt == 1){
			if(dprintf(log_fd, "SENT %d bytes: ", readable) < 0){
				fprintf(stderr, "Error: Could not print to log_fd.\nMessage: %s\nExiting with error number: %d\n", strerror(errno), errno);
				exit(1);
			}
			if(write(log_fd, &comp_buf, readable) < 0){
				fprintf(stderr, "Error: Could not write to log_fd.\nMessage: %s\nExiting with error number: %d\n", strerror(errno), errno);
				exit(1);
			}
			if(write(log_fd, "\n", 1) < 0){
				fprintf(stderr, "Error: Could not print to log_fd.\nMessage: %s\nExiting with error number: %d\n", strerror(errno), errno);
				exit(1);
			}
		}
	}


	else{ //not compressed

		if(write(fds[1].fd, &char_buf, readable) < 0){
				fprintf(stderr, "Error: Could not print to log_fd.\nMessage: %s\nExiting with error number: %d\n", strerror(errno), errno);
				exit(1);
			}
	

		if(log_opt == 1){
			if(dprintf(log_fd, "SENT %d bytes: ", readable) < 0){
				fprintf(stderr, "Error: Could not print to log_fd.\nMessage: %s\nExiting with error number: %d\n", strerror(errno), errno);
				exit(1);
			}
			if(write(log_fd, &char_buf, readable) < 0){
				fprintf(stderr, "%d Error: Could not write to log_fd.\nMessage: %s\nExiting with error number: %d\n", readable, strerror(errno), errno);
				exit(1);
			}
			if(write(log_fd, "\n", 1) < 0){
				fprintf(stderr, "Error: Could not print to log_fd.\nMessage: %s\nExiting with error number: %d\n", strerror(errno), errno);
				exit(1);
			}
		}
	}
}



	//if(write(fds[1].fd, &char_buf, readable) < 0){
//		fprintf(stderr, "Error: Could not write to socket.\nMessage: %s\nExiting with error number: %d\n", strerror(errno), errno);
	//	exit(1);
	//}
//closes function





void init_compress_to_stream(){
	comp_to_serv.zalloc = Z_NULL;
	comp_to_serv.zfree = Z_NULL;
	comp_to_serv.opaque = Z_NULL;

	
	if (deflateInit(&comp_to_serv, Z_DEFAULT_COMPRESSION) != Z_OK) {
		fprintf(stderr, "Error: Could not initialize deflate stream.\nMessage: %s\nExiting with error number: %d\n", strerror(errno), errno);
		exit(1);
	}	
} //closes function

void init_decomp_from_stream(){
	decomp_from_serv.zalloc = Z_NULL;
	decomp_from_serv.zfree = Z_NULL;
	decomp_from_serv.opaque = Z_NULL;

	
	if(inflateInit(&decomp_from_serv) != Z_OK){
		fprintf(stderr, "Error: Could not initialize inflate stream.\nMessage: %s\nExiting with error number: %d\n", strerror(errno), errno);
		exit(1);
	}
}


void deflate_stream(void * orig_buf, int orig_len, void * out_buf, int out_len){
	comp_to_serv.avail_in = orig_len;
	comp_to_serv.next_in = orig_buf;
	comp_to_serv.avail_out = out_len;
	comp_to_serv.next_out = out_buf;
	do{
		deflate(&comp_to_serv, Z_SYNC_FLUSH);
	}while(comp_to_serv.avail_in > 0);
}

void inflate_stream(void * orig_buf, int orig_len, void * out_buf, int out_len){
	decomp_from_serv.avail_in = orig_len;
	decomp_from_serv.next_in = orig_buf;
	decomp_from_serv.avail_out = out_len;
	decomp_from_serv.next_out = out_buf;
	do{
		inflate(&decomp_from_serv, Z_SYNC_FLUSH);
	}while(decomp_from_serv.avail_in > 0);
}


void compEnd(){
	deflateEnd(&comp_to_serv);
	inflateEnd(&decomp_from_serv);
	reset_input_mode();
}



int client_connect(char* hostname, unsigned int port_num){
	struct sockaddr_in serv_addr;
	int sock_fd;
	if((sock_fd = socket(AF_INET, SOCK_STREAM, 0)) == -1){
		fprintf(stderr, "Error: Could not create socket.\nMessage: %s\nExiting with error number: %d\n", strerror(errno), errno);
		exit(1);
	}
	struct hostent *server;
	server = gethostbyname(hostname); //converts host name to ip address
	memset(&serv_addr, 0, sizeof(struct sockaddr_in));
	serv_addr.sin_family = AF_INET; //address is Ipv4
	memcpy(&serv_addr.sin_addr.s_addr, server->h_addr, server->h_length); //copy ip address from server to serv_addr
	serv_addr.sin_port = htons(port_num); //setup the port
	if(connect(sock_fd, (struct sockaddr *) &serv_addr, sizeof(serv_addr)) == -1){ //initiate the connection to server
		fprintf(stderr, "Error: Could not connect to server.\nMessage: %s\nExiting with error number: %d\n", strerror(errno), errno);
		exit(1);
	} 
	return sock_fd;
}



int read_input_sock_to_disp(struct pollfd fds[], int log_opt, int log_fd, int comp_opt){
	char char_buf[2048];
	char curr_char;
	int readable;
	unsigned int i = 0;
	int j = 0;
	if((readable = read(fds[1].fd, &char_buf, 2048)) == -1){
		fprintf(stderr, "Error: Could not read from socket.\nMessage: %s\nExiting with error number: %d\n", strerror(errno), errno);
		exit(1);
	}

	if(comp_opt == 1){
		char comp_buf[2048];
		inflate_stream(char_buf, readable, comp_buf, 2048);

		//write(1, comp_buf, 2048 - decomp_from_serv.avail_out); //TEST

		while(i < (2048 - decomp_from_serv.avail_out)){
			curr_char = comp_buf[i];
			if((curr_char == '\r')||(curr_char == '\n')){
				if(write(1, "\r", 1) < 0){
					fprintf(stderr, "Error: Could not write to display.\nMessage: %s\nExiting with error number: %d\n", strerror(errno), errno);
					exit(1);
				}
			}
			if(write(1, &curr_char, 1) < 0){
				fprintf(stderr, "Error: Could not write to display.\nMessage: %s\nExiting with error number: %d\n", strerror(errno), errno);
				exit(1);
			}
			i++;
		}

		if(log_opt == 1){
			if(dprintf(log_fd, "RECEIVED %d bytes: ", readable) < 0){
				fprintf(stderr, "Error: Could not print to log_fd.\nMessage: %s\nExiting with error number: %d\n", strerror(errno), errno);
				exit(1);
			}
			if(write(log_fd, &char_buf, readable) < 0){
				fprintf(stderr, "Error: Could not write to log_fd.\nMessage: %s\nExiting with error number: %d\n", strerror(errno), errno);
				exit(1);
			}
			if(write(log_fd, "\n", 1) < 0){
				fprintf(stderr, "Error: Could not print to log_fd.\nMessage: %s\nExiting with error number: %d\n", strerror(errno), errno);
				exit(1);
			}
		}
	}


	else{
		while(j < readable){
			curr_char = char_buf[j];
			if((curr_char == '\r')||(curr_char == '\n')){
				if(write(1, "\r", 1) < 0){
					fprintf(stderr, "Error: Could not write to display.\nMessage: %s\nExiting with error number: %d\n", strerror(errno), errno);
					exit(1);
				}
				if(write(1, "\n", 1) < 0){
					fprintf(stderr, "Error: Could not write to display.\nMessage: %s\nExiting with error number: %d\n", strerror(errno), errno);
					exit(1);
				}
			}
			else{
				if(write(1, &curr_char, 1) < 0){
					fprintf(stderr, "Error: Could not write to display.\nMessage: %s\nExiting with error number: %d\n", strerror(errno), errno);
					exit(1);
				}
			}
			j++;
		}

		if(log_opt == 1){
			if(dprintf(log_fd, "RECEIVED %d bytes: ", readable) < 0){
				fprintf(stderr, "Error: Could not print to log_fd.\nMessage: %s\nExiting with error number: %d\n", strerror(errno), errno);
				exit(1);
			}

			if(write(log_fd, &char_buf, readable) < 0){
				fprintf(stderr, "%d Error: Could not write to log_fd.\nMessage: %s\nExiting with error number: %d\n", readable, strerror(errno), errno);
				exit(1);
			}

			if(write(log_fd, "\n", 1) < 0){
				fprintf(stderr, "Error: Could not print to log_fd.\nMessage: %s\nExiting with error number: %d\n", strerror(errno), errno);
				exit(1);
			}

		}
	}

	return readable;
}

