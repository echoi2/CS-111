//NAME: Eugene Choi
//EMAIL: echoi2@g.ucla.edu
//UID: 905368197

#include <stdio.h>
#include <stdlib.h> 
#include <errno.h>
#include <getopt.h>
#include <unistd.h>
#include <termios.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <signal.h>
#include <string.h>
#include <poll.h>       
#include <sys/socket.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <netinet/in.h> //including this allows me to see symbols from <arpa/inet.h> which has htons function in it.
#include "zlib.h"

z_stream comp_to_client;
z_stream decomp_from_client;
pid_t pid;
int pipe1[2]; //pipe from server to shell
int pipe2[2]; //pipe from shell to server
int child_status;


int server_connect(unsigned int port_num, int* socket_fd); 
void sig_handler(int sig);
void input_forward_p_to_s(int new_socket_fd, int* exit_D_or_C, int comp_opt);
void input_forward_s_to_p(struct pollfd fds[], int comp_opt);
void init_decomp_from_client();
void init_compress_to_client();
void deflate_stream(void * orig_buf, int orig_len, void * out_buf, int out_len);
void inflate_stream(void * orig_buf, int orig_len, void * out_buf, int out_len);
void compEnd(); //inflate end

int main(int argc, char * argv[]) {
    int option_index = 0;
    int opt = 0;
    int socket_fd, new_socket_fd, port, port_opt, comp_opt, shell_opt, exit_D_or_C;    // port number, port option, comp_option, shell_option (1 = true, 0 = false) 
    char* name_of_file; //used for the shell option. If shell option is not specified we just /bin/bash
    
    port_opt = 0;
    comp_opt = 0;
    shell_opt = 0;
    port = -1;


    static struct option long_options[] = {
    {"port", required_argument, NULL, 'p'},
    {"compress", no_argument, NULL, 'c'},
    {"shell", required_argument, NULL, 's'},
    {0,0,0,0}};




    while((opt = getopt_long(argc, argv, "p:cs:d", long_options, &option_index)) != -1){ //colon next to the optstring signifies that the option requires an argument
        switch(opt){
            case 'p':
                port_opt = 1;
                port = atoi(optarg); //Grabs the argument (port # in string) for the port option and converts it into an int.
                break;
            case 'c': 
                comp_opt = 1;
                break;
            case 's':
                shell_opt = 1;
                name_of_file = optarg;
                break;
            default:
                fprintf(stderr,"Error: The option/options provided are incorrect. The only options with arguments accepted are --port=port#, --compress, --shell=program, and --debug.");
                exit(1);
        } //closes switch(opt)
    } //closes while loop for opt = ...

    if(port_opt == 0){
        fprintf(stderr,"Error: Port option is mandatory");
        exit(1);
    }


    if(comp_opt == 1){
            init_compress_to_client();
            init_decomp_from_client();
            atexit(compEnd);
        }

    if(port_opt ==1){ //go here if port option is selected
        if(shell_opt == 0){
            name_of_file = "/bin/bash"; //If the shell option is not specified, /bin/bash is the script used.
        }

        if(port == -1){
            fprintf(stderr,"Error: Port number invalid.");
            exit(1);
        }
        new_socket_fd = server_connect(port, &socket_fd); //conn_fd's value (nonnegative integer file descriptor for accepted socket) is assigned to socket_fd

        //If connection is successful, fork child and start making the pipes
        if((pipe(pipe1)) != 0){
            fprintf(stderr, "Error: Failed to create pipe from server to shell.\nMessage: %s\nExiting with error number: %d\n", strerror(errno), errno);
            exit(1);
        }
        if((pipe(pipe2)) != 0){
            fprintf(stderr, "Error: Failed to create a pipe from the shell to server.\nMessage: %s\nExiting with error number: %d\n", strerror(errno), errno);
            exit(1);
        }

        signal(SIGPIPE, sig_handler); //Now if SIGPIPE appears anywhere after, then this signal function call will handle it.
        
        if((pid = fork()) == -1){  //forking a child process
            fprintf(stderr, "Error: Failed while forking.\nMessage: %s\nExiting with error number: %d\n", strerror(errno), errno);
            exit(1);
        }

        if(pid == 0){        //child process
            close(pipe1[1]); //closes the write from server to shell
            close(pipe2[0]); //closes the read from shell to server
            dup2(pipe1[0],0);
            dup2(pipe2[1],1);
            dup2(pipe2[1],2);
            close(pipe1[0]); //Replaced using dup2, so now we just close because it's not being used.
            close(pipe2[1]);
            char* arguments[2];     //An array of character pointers to NULL-terminated strings. Your application must ensure that the last member of this array is a NULL
                                    //pointer. The value in argv[0] must point to a filename that's associated with the process being started. Neither argv nor the value in
                                    //argv[0] can be NULL.

            arguments[0] = name_of_file;
            arguments[1] = NULL;
            if((execvp(name_of_file, arguments)) == -1){ //executes the shell and also checks whether or not execution is successful
                fprintf(stderr,"Error: Execution of shell in child process was not successful.\nMessage: %s\nExiting with error number: %d\n", strerror(errno), errno);
                exit(1);
            }
        } //closes pid==0

        else if (pid > 0){ //parent process
            close(pipe1[0]);
            close(pipe2[1]);
            struct pollfd fds[2];
            int poll_val;
            fds[0].fd = new_socket_fd;
            fds[1].fd = pipe2[0]; //pipe from shell to server output
            fds[0].events = POLLIN | POLLHUP | POLLERR;
            fds[1].events = POLLIN | POLLHUP | POLLERR;




            while(1){
                poll_val = poll(fds, 2, 0);

                if(poll_val > 0){

                    if(fds[0].revents & POLLIN){
                        input_forward_p_to_s(new_socket_fd, &exit_D_or_C, comp_opt); //input forwarded through pipe to shell
                    }

                    if(fds[0].revents & POLLHUP){
                        close(pipe1[1]); //Closed the write end of pipe to shell
                        //close(pipe2[0]); //maybe add back in later cause the read end of the pipe from shell to server is still open I believe by the parent process
                        waitpid(pid, &child_status, 0);
                        fprintf(stderr,"SHELL EXIT SIGNAL=%d STATUS=%d ", WIFSIGNALED(child_status), WEXITSTATUS(child_status));
                        close(socket_fd);
                        close(new_socket_fd);
                        exit(0);
                    }

                    if(fds[0].revents & POLLERR){
                        fprintf(stderr,"Error: Recieved a POLLERR.\nMessage: %s\nExiting with error number: %d\n", strerror(errno), errno);
                        close(pipe1[1]); //Closed the write end of pipe to shell
                        //close(pipe2[0]); //maybe add back in later cause the read end of the pipe from shell to server is still open I believe by the parent process
                        waitpid(pid, &child_status, 0);
                        fprintf(stderr,"SHELL EXIT SIGNAL=%d STATUS=%d ", WIFSIGNALED(child_status), WEXITSTATUS(child_status));
                        close(socket_fd);
                        close(new_socket_fd);
                        exit(1);
                    }

                    if(fds[1].revents & POLLIN){
                        input_forward_s_to_p(fds, comp_opt);
                    }
                    
                    if(fds[1].revents & POLLHUP){
                        close(pipe1[1]); //Closed the write end of pipe to shell
                       // close(pipe2[0]); //maybe add back in later cause the read end of the pipe from shell to server is still open I believe by the parent process
                        waitpid(pid, &child_status, 0);
                        fprintf(stderr,"SHELL EXIT SIGNAL=%d STATUS=%d ", WIFSIGNALED(child_status), WEXITSTATUS(child_status));
                        close(socket_fd);
                        close(new_socket_fd);
                        exit(0);
                    }

                    if(fds[1].revents & POLLERR){
                        fprintf(stderr,"Error: Recieved POLLERR.\nMessage: %s\nExiting with error number: %d\n", strerror(errno), errno);
                        close(pipe1[1]); //Closed the write end of pipe to shell
                        //close(pipe2[0]); //maybe add back in later cause the read end of the pipe from shell to server is still open I believe by the parent process
                        waitpid(pid, &child_status, 0);
                        fprintf(stderr,"SHELL EXIT SIGNAL=%d STATUS=%d ", WIFSIGNALED(child_status), WEXITSTATUS(child_status));
                        close(socket_fd);
                        close(new_socket_fd);
                        exit(1);
                    }
                    if(exit_D_or_C == 2){ //This is case 0x04 case
                        close(pipe1[1]); //Closed the write end of pipe to shell
                        //close(pipe2[0]); //maybe add back in later cause the read end of the pipe from shell to server is still open I believe by the parent process
                        waitpid(pid, &child_status, 0);
                        fprintf(stderr,"SHELL EXIT SIGNAL=%d STATUS=%d ", WIFSIGNALED(child_status), WEXITSTATUS(child_status));
                        close(socket_fd);
                        close(new_socket_fd);
                        exit(0);
                    }

                    if(exit_D_or_C == 1){ //This is 0x03 case
                        if(kill(pid, SIGINT) < 0){
                            waitpid(pid, &child_status, 0);
                            fprintf(stderr, "Error: Problem with child process.\nMessage: %s\nExiting with error number: %d\n", strerror(errno), errno);
                            exit(1);              
                        }
                        waitpid(pid, &child_status, 0); //maybe come back and change
                        fprintf(stderr,"SHELL EXIT SIGNAL=%d STATUS=%d ", WIFSIGNALED(child_status), WEXITSTATUS(child_status));
                    }
                } //closes if poll_val > 0

                else if(poll_val < 0){
                    fprintf(stderr,"Error: Poll creation failed.\nMessage: %s\nExiting with error number: %d\n", strerror(errno), errno);
                    waitpid(pid, &child_status, 0); //maybe come back and change
                    fprintf(stderr,"SHELL EXIT SIGNAL=%d STATUS=%d ", WIFSIGNALED(child_status), WEXITSTATUS(child_status));                    
                    exit(1);
                }

            } //closes while(1) loop

        } //closes else if loop

    } //closes else loop (port==1 option)
    exit(0);
} //closes int main 




////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//Functions




int server_connect(unsigned int port_num, int* socket_fd)  //referenced from discussion section notes
                                           //port_num: which port server listens to, return socket for subsequent communication
{
    int listen_fd, con_fd;                      //socket descriptor, connection socket descriptor (equiv. to retfd used in discussion notes)

    struct sockaddr_in serv_addr, cli_addr; //referenced from geeksforgeeks.org/tcp-server-client-implementation-in-c/
                                               //These are basic structures for all syscalls and functions that deal with internet addresses
  
    unsigned int client_len = sizeof(struct sockaddr_in); //used for the accepting part in server side task
    
    con_fd = 0; //used in the acceptance part. This is the connection file descriptor that will be assigned the int value returned from the accept function

    if((listen_fd = socket(AF_INET, SOCK_STREAM, 0)) == -1){ //This creates the socket and basically does an error check to let you know if socket can be created
        fprintf(stderr, "Error: Could not create socket.\nMessage: %s\nExiting with error number: %d\n", strerror(errno), errno);
        exit(1);
    }
    *socket_fd = listen_fd; //just assigns listen_fd's value to the socket_fd variable in the main. Just for keeping tabs on the value that you get.
    memset(&serv_addr, 0, sizeof(struct sockaddr_in)); 
    serv_addr.sin_family = AF_INET;         //ipv4 address
    serv_addr.sin_addr.s_addr = INADDR_ANY; //server can accept connection from any client IP
    serv_addr.sin_port = htons(port_num);   //setup port number

    if((bind(listen_fd, (struct sockaddr *) &serv_addr, sizeof(serv_addr))) == -1){ //bind socket to port.
        fprintf(stderr, "Error: Could not bind socket.\nMessage: %s\nExiting with error number: %d\n", strerror(errno), errno);
        exit(1);
    } 

    if((listen(listen_fd, 5)) == -1){ //let socket listen , maximum pending 5 connections
        fprintf(stderr, "Error: Server could not listen.\nMessage: %s\nExiting with error number: %d\n", strerror(errno), errno);
        exit(1);
    }

    if((con_fd = accept(listen_fd, (struct sockaddr *) &cli_addr, & client_len)) == -1){ //wait for client's connection, client_addr stores the client's address accept returns a file descriptor for the accepted socket (a nonnegative integer).
        fprintf(stderr, "Error: Server did not accept data packet from client and verification.\nMessage: %s\nExiting with error number: %d\n", strerror(errno), errno);
        exit(1);
    } 

    return con_fd;
}






void sig_handler(int sig){
  if(sig == SIGPIPE){
    fprintf(stderr,"Recieved a SIGPIPE. Getting ready to shut-down.");
    waitpid(pid, &child_status, 0);
    fprintf(stderr,"SHELL EXIT SIGNAL=%d STATUS=%d ", WIFSIGNALED(child_status), WEXITSTATUS(child_status));
    exit(0);
    //some additional stuff here
  }
}


void init_decomp_from_client(){
    decomp_from_client.zalloc = Z_NULL;
    decomp_from_client.zfree = Z_NULL;
    decomp_from_client.opaque = Z_NULL;

    
    if (inflateInit(&decomp_from_client) != Z_OK) {
        fprintf(stderr, "Error: Could not initialize inflate stream.\nMessage: %s\nExiting with error number: %d\n", strerror(errno), errno);
        exit(1);
    }
}



void init_compress_to_client(){
    comp_to_client.zalloc = Z_NULL;
    comp_to_client.zfree = Z_NULL;
    comp_to_client.opaque = Z_NULL;

    if (deflateInit(&comp_to_client, Z_DEFAULT_COMPRESSION) != Z_OK) {
        fprintf(stderr, "Error: Could not initialize deflate stream.\nMessage: %s\nExiting with error number: %d\n", strerror(errno), errno);
        exit(1);
    }
}

void deflate_stream(void * orig_buf, int orig_len, void * out_buf, int out_len){
    comp_to_client.avail_in = orig_len;
    comp_to_client.next_in = orig_buf;
    comp_to_client.avail_out = out_len;
    comp_to_client.next_out = out_buf;
    do{
        deflate(&comp_to_client, Z_SYNC_FLUSH);
    }while(comp_to_client.avail_in > 0);
}


void inflate_stream(void * orig_buf, int orig_len, void * out_buf, int out_len){
    decomp_from_client.avail_in = orig_len;
    decomp_from_client.next_in = orig_buf;
    decomp_from_client.avail_out = out_len;
    decomp_from_client.next_out = out_buf;
    do{
        inflate(&decomp_from_client, Z_SYNC_FLUSH);
    }while(decomp_from_client.avail_in > 0);
}



void compEnd(){
    deflateEnd(&comp_to_client);
    inflateEnd(&decomp_from_client);
}


void input_forward_p_to_s(int new_socket_fd, int* exit_D_or_C, int comp_opt){
    char char_buff[2048];
    char curr_char;
    int readable;
    unsigned int i = 0;
    int k = 0;
    if((readable = read(new_socket_fd, &char_buff, 2048)) == -1){
        fprintf(stderr, "Error: Could not read.\nMessage: %s\nExiting with error number: %d\n", strerror(errno), errno);
        exit(1);
    }
    if(comp_opt == 1){
        char comp_buff[2048];
        inflate_stream(char_buff, readable, comp_buff, 2048);

        while(i < (2048 - decomp_from_client.avail_out)){
            curr_char = comp_buff[i];
            switch(curr_char){
                case '\r':
                case '\n': //don't echo 
                    if((write(pipe1[1], "\n", 1)) < 0){ //write to shell after reading from socket
                        fprintf(stderr, "Error: Could not write.\nMessage: %s\nExiting with error number: %d\n", strerror(errno), errno);
                        exit(1);
                    }
                    //write(1, "\n", 1); //TEST
                    break;
                case 0x03: //^C
                    *exit_D_or_C = 1;
                    break;
                case 0x04: //^D
                    *exit_D_or_C = 2;
                    break;
                default:
                    if((write(pipe1[1], &curr_char, 1)) < 0){
                        fprintf(stderr, "Error: Could not write.\nMessage: %s\nExiting with error number: %d\n", strerror(errno), errno);
                        exit(1);
                    }
                   // write(1, &curr_char, 1); //TEST
                    break;
            }
            i++;
        }
    }
    
    else{
        while(k < readable){
            curr_char = char_buff[k];
            switch(curr_char){
                case '\r':
                case '\n': //don't echo 
                    if((write(pipe1[1], "\n", 1)) < 0){ //write to shell after reading from socket
                        fprintf(stderr, "Error: Could not write.\nMessage: %s\nExiting with error number: %d\n", strerror(errno), errno);
                        exit(1);
                    }
                    break;
                case 0x03: //^C
                    *exit_D_or_C = 1;
                    break;
                case 0x04: //^D
                    *exit_D_or_C = 2;
                    break;
                default:
                    if((write(pipe1[1], &curr_char, 1)) < 0){
                        fprintf(stderr, "Error: Could not write.\nMessage: %s\nExiting with error number: %d\n", strerror(errno), errno);
                        exit(1);
                    }
                    break;
            }
            k++;
        }
    }
}





void input_forward_s_to_p(struct pollfd fds[], int comp_opt){ //getting things from shell and sending back to network.
    char char_buff[2048];
    int readable;
    if((readable = read(fds[1].fd, &char_buff, 2048)) < 0){
        fprintf(stderr, "Error: Could not read.\nMessage: %s\nExiting with error number: %d\n", strerror(errno), errno);
        exit(1);
    }

    if(comp_opt == 1){
        char comp_buff[2048];
        deflate_stream(char_buff, readable, comp_buff, 2048);
        if((write(fds[0].fd, &comp_buff, 2048 - comp_to_client.avail_out)) < 0){
            fprintf(stderr, "Error: Could not write.\nMessage: %s\nExiting with error number: %d\n", strerror(errno), errno);
            exit(1);
        }
    }
    else{
        if((write(fds[0].fd, &char_buff, readable)) < 0){
            fprintf(stderr, "Error: Could not write from shell to stdout.\nMessage: %s\nExiting with error number: %d\n", strerror(errno), errno);
            exit(1);
        }
    } 
}
